package classbuilder.demo.report;

// simple test data
public class TestData {
	private String value1;
	
	public TestData() {
		value1 = "data";
	}
	
	public String getValue1() {
		return value1;
	}
}
